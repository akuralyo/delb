package com.kreative.delb.security;

public enum Role {
	ADMIN,
	AUTHOR,
	READER
}
